package com.e_commerce.ms_envios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEnviosApplicationTests {

	@Test
	void contextLoads() {
	}

}
