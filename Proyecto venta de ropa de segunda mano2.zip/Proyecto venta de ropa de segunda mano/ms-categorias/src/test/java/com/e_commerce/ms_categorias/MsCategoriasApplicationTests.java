package com.e_commerce.ms_categorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCategoriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
