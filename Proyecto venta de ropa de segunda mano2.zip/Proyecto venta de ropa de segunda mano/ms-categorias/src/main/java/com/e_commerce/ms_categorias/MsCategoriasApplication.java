package com.e_commerce.ms_categorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication
@EnableDiscoveryClient
public class MsCategoriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCategoriasApplication.class, args);

	}
}
