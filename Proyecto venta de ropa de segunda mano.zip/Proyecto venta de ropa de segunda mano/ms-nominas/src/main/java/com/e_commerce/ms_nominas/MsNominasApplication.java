package com.e_commerce.ms_nominas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class MsNominasApplication {
	public static void main(String[] args) {
		SpringApplication.run(MsNominasApplication.class, args);
	}
}