package com.duoc.nominas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsNominasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsNominasApplication.class, args);
	}

}
