package com.duoc.nominas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsNominasApplicationTests {

	@Test
	void contextLoads() {
	}

}
