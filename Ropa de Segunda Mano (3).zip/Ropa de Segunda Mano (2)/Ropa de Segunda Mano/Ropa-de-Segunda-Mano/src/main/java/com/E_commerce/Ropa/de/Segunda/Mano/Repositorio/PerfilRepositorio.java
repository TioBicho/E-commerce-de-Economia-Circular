package com.E_commerce.Ropa.de.Segunda.Mano.Repositorio;

import com.tienda.profiles.model.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PerfilRepositorio extends JpaRepository<Profile, Long> {

    Optional<Profile> findByUsername(String username);
}

